const feedEl = document.querySelectorAll(".feed");
const btnEl = document.getElementById("btn");
const containerEl = document.querySelector(".container")
let selectedItem;
feedEl.forEach((feed)=>{
   feed.addEventListener('click', e =>{
      removeActive();
      selectedItem = e.target.innerText || e.target.parentNode.innerText;
      e.target.classList.add("active")
      e.target.parentElement.classList.add("active")
   })
})

function removeActive(e) {
   feedEl.forEach((feed)=>{
      feed.classList.remove("active")
   })
}

btnEl.addEventListener("click", (e)=>{
   if (!selectedItem !== "") {
      containerEl.innerHTML = `<strong>Thank you!</strong>
      <br>
      <br>
       <strong>Feedback: ${selectedItem}</strong>
       <br>
       <br>
        <strong>We will use your feedback yo improve our customers</strong>
        <br>
        <br>
      `
   }
})